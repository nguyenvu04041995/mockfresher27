package model.Dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;



import model.Bean.Region;
/**
 * RegionDao.java
 *
 * Date: May ‎8, ‎2017
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * May ‎8, ‎2017        	VuNQ2         Create
 */
public class RegionDao {

	/**
	 * List danh sach Region
	 * 
	 * @return list
	 */
	public ArrayList<Region> getlistRegion() {
		ConnectData.connection = ConnectData.getconnect();
		String sql = "select right(RegionName,2) as stt,RegionName,RegionCode,Description from Region order by stt asc";
		ResultSet rs = null;
		Statement stmt = null;
		try {
			stmt = ConnectData.connection.createStatement();
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			;
		}
		ArrayList<Region> list;
		list = new ArrayList<>();
		Region region;
		try {
			while (rs.next()) {
				region = new Region();
				region.setRegionCode(rs.getString("RegionCode"));
				if (rs.getString("RegionName") != null) {
					region.setRegionName(rs.getString("RegionName"));
				}
				region.setDescription(rs.getString("Description"));
				list.add(region);
			}
		} catch (SQLException e) {

		} finally {
			try {
				rs.close();
			} catch (SQLException e) {
				;
			}
			try {
				stmt.close();
			} catch (SQLException e) {

			}

		}
		return list;
	}

	/**
	 * Lay thong tin qua form Update Region
	 * 
	 * @param regionCode
	 * @return region
	 */
	public Region getThongtinRegion(String regionCode) {
		ConnectData.connection = ConnectData.getconnect();
		String sql = String.format(" Select RegionCode,RegionName,Description from Region where RegionCode='%s'",
				regionCode);
		ResultSet rs = null;
		Statement stmt = null;
		try {
			stmt = ConnectData.connection.createStatement();
			rs = stmt.executeQuery(sql);

		} catch (SQLException e) {
			;
		}
		Region region = new Region();
		try {
			while (rs.next()) {
				region = new Region();
				region.setRegionCode(regionCode);
				region.setRegionName(rs.getString("RegionName"));
				region.setDescription(rs.getString("Description"));
			}
		} catch (SQLException e) {
			;
		} finally {
			try {
				rs.close();
			} catch (SQLException e) {
				;
			}
			try {
				stmt.close();
			} catch (SQLException e) {
				;
			}
		}
		return region;
	}

	/**
	 * Xem danh sach Region tương ứng đối với 1 giá trị chon trong combobox RegionName
	 * 
	 * @param regionName
	 * @return
	 */
	public ArrayList<Region> getListRegionDao(String regionName) {
		ConnectData.connection = ConnectData.getconnect();
		String sql = String.format("Select RegionCode,RegionName,Description from Region where RegionName='%s'",
				regionName);
		ResultSet rs = null;
		Statement stmt = null;
		try {
			stmt = ConnectData.connection.createStatement();
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			;
		}
		ArrayList<Region> list;
		list= new ArrayList<>();
		Region region;
		try {
			while (rs.next()) {
				region = new Region();
				region.setRegionCode(rs.getString("RegionCode"));
				region.setRegionName(rs.getString("RegionName"));
				region.setDescription(rs.getString("Description"));
				list.add(region);
			}
		} catch (SQLException e) {
			;
		}
		return list;
	}

	/**
	 * Them moi mot Region
	 * 
	 * @param regionCode
	 * @param regionName
	 * @param description
	 *            ewturn false
	 */
	public boolean themRegion(String regionCode, String regionName, String description) {
		ConnectData.connection = ConnectData.getconnect();
		String sql = String.format("Insert into Region (RegionCode,RegionName,Description)" + "values('%s','%s','%s')",
				regionCode, regionName, description);
		Statement stmt = null;

		try {
			stmt = ConnectData.connection.createStatement();
			stmt.executeUpdate(sql);
			return true;
		} catch (SQLException e) {
			;
		} finally {

			try {
				stmt.close();
			} catch (SQLException e) {
				;
			}
		}
		return false;

	}

	/**
	 * Sua mot Region da co
	 * 
	 * @param regionCode
	 * @param regionName
	 * @param description
	 * @return flase
	 */
	public boolean suaRegion(String regionCode, String regionName, String description) {
		ConnectData.connection = ConnectData.getconnect();
		String sql = String.format("UPDATE Region SET RegionName ='%s',Description='%s' WHERE RegionCode ='%s'",
				regionName, description, regionCode);
		Statement stmt = null;
		try {
			stmt = ConnectData.connection.createStatement();
			stmt.executeUpdate(sql);
			return true;
		} catch (SQLException e) {
			;
		} finally {

			try {
				stmt.close();
			} catch (SQLException e) {
				;
			}
		}
		return false;
	}

	/**
	 * Kiem tra khi them moi 1 Region thi RegionCode có trung k???
	 * 
	 * @param regionCode
	 * @return false
	 */
	public boolean checkregionCode(String regionCode) {
		ConnectData.connection = ConnectData.getconnect();
		String sql = String.format("SELECT * from Region WHERE RegionCode = '%s'", regionCode);
		ResultSet rs = null;
		Statement stmt = null;
		try {
			stmt = ConnectData.connection.createStatement();
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			if (rs.next()) {
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
			} catch (SQLException e) {
				;
			}
			try {
				stmt.close();
			} catch (SQLException e) {
				;
			}
		}
		return false;
	}

}
