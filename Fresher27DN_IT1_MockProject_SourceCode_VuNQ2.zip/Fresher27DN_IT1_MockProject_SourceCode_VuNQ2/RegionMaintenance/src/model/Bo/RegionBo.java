package model.Bo;

import java.util.ArrayList;
import model.Bean.Region;
import model.Dao.RegionDao;

/**
 * RegionBo.java
 *
 * Date: May ‎8, ‎2017
 *
 * Copyright
 *
 * Modification Logs: DATE AUTHOR DESCRIPTION
 * ----------------------------------------------------------------------- May
 * ‎8, ‎2017 VuNQ2 Create
 */

public class RegionBo {
	RegionDao regionDao = new RegionDao();

	/**
	 * @return
	 */
	public ArrayList<Region> getlistRegion() {
		return regionDao.getlistRegion();

	}

	/**
	 * @param regionCode
	 * @return
	 */
	public Region getThongtinRegion(String regionCode) {
		return regionDao.getThongtinRegion(regionCode);

	}

	/**
	 * @param regionName
	 * @return
	 */
	public ArrayList<Region> getListRegionDao(String regionName) {
		return regionDao.getListRegionDao(regionName);
	}

	/**
	 * @param regionCode
	 * @param regionName
	 * @param description
	 */
	public boolean themRegion(String regionCode, String regionName, String description) {
		return regionDao.themRegion(regionCode, regionName, description);
	}

	/**
	 * @param regionCode
	 * @param regionName
	 * @param description
	 */
	public boolean suaRegion(String regionCode, String regionName, String description) {
		return regionDao.suaRegion(regionCode, regionName, description);
		
	}

	/**
	 * @param regionCode
	 * @return
	 */
	public boolean checkregionCode(String regionCode) {
		return regionDao.checkregionCode(regionCode);
	}
}
