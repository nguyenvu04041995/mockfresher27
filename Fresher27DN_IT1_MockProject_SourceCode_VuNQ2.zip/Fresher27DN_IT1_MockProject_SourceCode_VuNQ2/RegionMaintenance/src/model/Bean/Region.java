package model.Bean;

/**
 * Region.java
 *
 * Date: May ‎8, ‎2017
 *
 * Copyright
 *
 * Modification Logs: 
 * DATE 			AUTHOR 		DESCRIPTION
 * ----------------------------------------------------------------------- 
 * May 8, ‎2017 		VuNQ2 		Create
 */
public class Region {
	private String regionCode;
	private String regionName;
	private String description;
	
	/**
	 * @param regionCode
	 * @param regionName
	 * @param description
	 */
	public Region(String regionCode, String regionName, String description) {
		super();
		this.regionCode = regionCode;
		this.regionName = regionName;
		this.description = description;
	}

	/**
	 * 
	 */
	public Region() {
		super();
	}

	/**
	 * @return the regionCode
	 */
	public String getRegionCode() {
		return regionCode;
	}

	/**
	 * @param regionCode
	 *            the regionCode to set
	 */
	public void setRegionCode(String regionCode) {
		this.regionCode = regionCode;
	}

	/**
	 * @return the regionName
	 */
	public String getRegionName() {
		return regionName;
	}

	/**
	 * @param regionName
	 *            the regionName to set
	 */

	public void setRegionName(String regionName) {
		this.regionName = regionName;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description
	 *            the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

}
