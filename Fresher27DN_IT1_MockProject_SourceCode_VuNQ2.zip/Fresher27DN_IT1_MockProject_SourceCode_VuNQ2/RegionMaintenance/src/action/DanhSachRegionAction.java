package action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import form.DanhSachRegionForm;
import model.Bean.*;
import model.Bo.RegionBo;
/**
 * DanhSachRegionAction.java
 *
 * Date: May ‎8, ‎2017
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * May ‎8, ‎2017        	VuNQ2         Create
 */


public class DanhSachRegionAction extends Action {

	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		DanhSachRegionForm danhSachRegionForm = (DanhSachRegionForm) form;
		/**
		 * Lay danh sach Region
		 */
		ArrayList<Region> listRegion;
		RegionBo regionBo = new RegionBo();
		String regionName = danhSachRegionForm.getRegionName();
		if (regionName == null || regionName.length() == 0) {
			listRegion = regionBo.getlistRegion();
		} else {
			listRegion = regionBo.getListRegionDao(regionName);
		}

		danhSachRegionForm.setListRegion(listRegion);
		return mapping.findForward("dsRegion");
	}

}
