package action;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;

import common.StringProcess;
import form.RegionForm;
import model.Bo.RegionBo;

/**
 * AddRegion.java
 * Name: Class Them Region
 * Date: May ‎8, ‎2017
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * May ‎8, ‎2017        	VuNQ2         Create
 */
public class AddRegion extends Action{
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("UTF-8");
		RegionForm regionForm = (RegionForm) form;

		/**
		 * Validate du lieu
		 */
		if ("Add".equals(regionForm.getSubmit())) {
			ActionErrors actionErrors = new ActionErrors();
			/**
			 * Kien tra RegionCode co rong khong
			 */
			if (StringProcess.notVaild(regionForm.getRegionCode())) {
				actionErrors.add("msvError", new ActionMessage("error.msv.trong"));
			}
			/**
			 * Kien tra RegionName co rong khong
			 */
			if (StringProcess.notVaildRegionName(regionForm.getRegionName())) {
				actionErrors.add("msvError1", new ActionMessage("error.msv1.regionnametrong"));
			}
			/**
			 * Kien tra RegionCode co nhap qua 20 ki tu
			 */
			if (StringProcess.maxlength(regionForm.getRegionCode())) {
				actionErrors.add("msvError2", new ActionMessage("error.msv2.khongqua20kt"));
			}
			/**
			 * Kien tra RegionName co nhap qua 50 ki tu
			 */
			if (StringProcess.maxlengthName(regionForm.getRegionName())) {
				actionErrors.add("msvError3", new ActionMessage("error.msv3.khongqua50kt"));
			}
			/**
			 * Kien tra Description co nhap qua 100 ki tu
			 */
			if (StringProcess.maxlengDescription(regionForm.getDescription())) {
				actionErrors.add("msvError4", new ActionMessage("error.msv4.khongqua100kt"));
			}
			/**
			 * Ham kiem tra RegionCode co space dau tien hay cuoi cung hoac 2 //
			 * dau cach lien tiep
			 */

			if (StringProcess.getValidSpaceFirstLastString(regionForm.getRegionCode())) {
				actionErrors.add("msvError5", new ActionMessage("error.msv5.daucach"));
			}
			/**
			 * Ham kiem tra RegionName co space dau tien hay cuoi cung hoac 2
			 * dau cach lien tiep
			 */
			if (StringProcess.getValidSpaceFirstLastString(regionForm.getRegionName())) {
				actionErrors.add("msvError51", new ActionMessage("error.msv51.daucach"));
			}
			/**
			 * Ham kiem tra xem xau co bao gom chu so hay ki tu dac biet
			 */
			if (StringProcess.notVaildString(regionForm.getRegionCode())) {
				actionErrors.add("msvError6", new ActionMessage("error.msv6.kitudacbiet"));
			}
			if (StringProcess.notVaildString(regionForm.getRegionName())) {
				actionErrors.add("msvError61", new ActionMessage("error.msv61.kitudacbiet"));
			}
			
			saveErrors(request, actionErrors);
			if (actionErrors.size() > 0) {
				return mapping.findForward("themSVerror");
			}
		}
		if ("Add".equals(regionForm.getSubmit())) {
			String regionCode = regionForm.getRegionCode();
			String regionName = regionForm.getRegionName();
			String description = regionForm.getDescription();
			ActionErrors actionErrors = new ActionErrors();
			RegionBo regionBo = new RegionBo();
			
			
          /**
           * kiem tra Khi them RegionCode moi da ton tai chua
           */
			 
			if (regionBo.checkregionCode(regionCode)) {
				actionErrors.add("RegionCodeError", new ActionMessage("error.regionCode.trung"));
			}
			saveErrors(request, actionErrors);
			if (actionErrors.size() > 0) {
				return mapping.findForward("themRegion");
			} else {
				regionBo.themRegion(regionCode, regionName, description);
				return mapping.findForward("themRegionxong");
			}
		} else {
			return mapping.findForward("themRegion");
		}
	}
}
