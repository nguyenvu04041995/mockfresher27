package action;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;

import common.StringProcess;
import form.*;
import model.Bean.*;
import model.Bo.*;
/**
 * UpdateRegion.java
 *
 * Date: May ‎8, ‎2017
 * NAME: Class Update Region
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * May ‎8, ‎2017        	VuNQ2         Create
 */
public class UpdateRegion extends Action {
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("UTF-8");
		RegionForm regionForm = (RegionForm) form;

		RegionBo regionBo;
		regionBo = new RegionBo();
		if ("Update".equals(regionForm.getSubmit())) {
			ActionErrors actionErrors = new ActionErrors();
			/**
			 * Kien tra RegionName co rong khong
			 */
			if (StringProcess.notVaildRegionName(regionForm.getRegionName())) {
				actionErrors.add("msvError1", new ActionMessage("error.msv1.regionnametrong"));
			}
			/**
			 * Kien tra RegionName co nhap qua 50 ki tu
			 */
			if (StringProcess.maxlengthName(regionForm.getRegionName())) {
				actionErrors.add("msvError3", new ActionMessage("error.msv3.khongqua50kt"));
			}
			/**
			 * Kien tra Description co nhap qua 100 ki tu
			 */
			if (StringProcess.maxlengDescription(regionForm.getDescription())) {
				actionErrors.add("msvError4", new ActionMessage("error.msv4.khongqua100kt"));
			}
			/**
			 * Ham kiem tra RegionName co space dau tien hay cuoi cung hoac 2
			 * dau cach lien tiep
			 */

			if (StringProcess.getValidSpaceFirstLastString(regionForm.getRegionName())) {
				actionErrors.add("msvError5", new ActionMessage("error.msv5.daucach"));
			}
			/**
			 * Ham kiem tra xem xau co bao gom chu so hay ki tu dac biet
			 */
			if (StringProcess.notVaildString(regionForm.getRegionName())) {
				actionErrors.add("msvError6", new ActionMessage("error.msv6.kitudacbiet"));
			}
			
			saveErrors(request, actionErrors);
			if (actionErrors.size() > 0) {
				return mapping.findForward("suaSVerror");
			}
		}
		/**
		 * Update Region
		 */
		String regionCode = regionForm.getRegionCode();
		if ("Update".equals(regionForm.getSubmit())) {
			String regionName = regionForm.getRegionName();
			String description = regionForm.getDescription();

			regionBo.suaRegion(regionCode, regionName, description);
			return mapping.findForward("suaRegionxong");
		} else {
			Region region = regionBo.getThongtinRegion(regionCode);
			regionForm.setRegionName(region.getRegionName());
			regionForm.setDescription(region.getDescription());

			return mapping.findForward("suaRegion");
		}
	}
}
