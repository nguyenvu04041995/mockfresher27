package common;
import java.text.Normalizer;
import java.util.regex.Pattern;
/**
 * 
 * @author HCD-Fresher235
 *
 */
public class StringProcess {

	/**
	* Kien tra  regionCode co null khong
	*/
	public static boolean notVaild(String regionCode) {
		return (regionCode==null || regionCode.length()==0)?true:false;
	}
	/**
	* Kien tra  regionName co null khong
	*/
	public static boolean notVaildRegionName(String regionName) {
		return (regionName==null || regionName.length()==0)?true:false;
	}
	/**
	* Kien tra  regionCode nhap qua 100 ki tu
	*/
	public static boolean maxlength(String regionCode) {
		return (regionCode.length()>20)?true:false;
	}

/**
* Kien tra  regionName nhap qua 100 ki tu
*/
	public static boolean maxlengthName(String regionName) {
		return (regionName.length()>50)?true:false;
	}
/**
 * Kien tra  description nhap qua 100 ki tu
 */
	public static boolean maxlengDescription(String description) {
		return (description.length()>100)?true:false;
	}

	/**
	 * Ham kiem tra xau co space dau tien hay cuoi cung hoac 2 dau cach lien tiep
	 * @param s
	 * @return boolean
	 */
	public static boolean getValidSpaceFirstLastString(String s) {
		String s1=s.trim();
		String s2=s.replaceAll("  ", " ");
		return ((s.length()>s1.length())&&(s.length()>s2.length()))?true:false;
	} 
/**
	 * Ham kiem tra xem xau co bao gom chu so hay ki tu dac biet
	 * @param s
	 * @return boolean
	 */
	public static boolean notVaildString(String s){
		if(notVaild(s)) return false;
		if(getValidSpaceFirstLastString(s)) return false;
		String temp = Normalizer.normalize(s, Normalizer.Form.NFD);
		Pattern pattern = Pattern.compile("\\p{InCombiningDiacriticalMarks}+");
		String s1 = pattern.matcher(temp).replaceAll("");
		String regex = "[a-zA-z0-9]+([ '-][a-zA-Z0-9]+)*"; 
		return (s1.matches(regex))?false:true;
	} 

}
