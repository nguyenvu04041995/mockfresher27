package form;
import java.util.ArrayList;
import org.apache.struts.action.ActionForm;
import model.Bean.Region;
/**
 * 
 * @author HCD-Fresher235
 *
 */
public class DanhSachRegionForm extends ActionForm {
	private static final long serialVersionUID = 1L;
	private String regionName;
	private ArrayList<Region> listRegion;

	/**
	 * @return the regionName
	 */
	public String getRegionName() {
		return regionName;
	}

	/**
	 * @param regionName
	 *            the regionName to set
	 */
	public void setRegionName(String regionName) {
		this.regionName = regionName;
	}

	/**
	 * @return the listRegion
	 */
	public ArrayList<Region> getListRegion() {
		return listRegion;
	}

	/**
	 * @param listRegion
	 *            the listRegion to set
	 */
	public void setListRegion(ArrayList<Region> listRegion) {
		this.listRegion = listRegion;
	}

	/**
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	/**
	 * 
	 */
	/**
	 * @param regionName
	 * @param listRegion
	 */
	public DanhSachRegionForm(String regionName, ArrayList<Region> listRegion) {
		super();
		this.regionName = regionName;
		this.listRegion = listRegion;
	}

	/**
	 * 
	 */
	public DanhSachRegionForm() {
		super();
	}

}
