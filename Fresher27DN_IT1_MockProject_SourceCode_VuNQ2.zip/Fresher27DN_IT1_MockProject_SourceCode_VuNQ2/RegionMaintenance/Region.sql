USE [master]
GO
CREATE DATABASE [RegionMaintenance ]
GO
USE [RegionMaintenance ]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Region](
	[RegionCode] [nvarchar](20) NOT NULL,
	[RegionName] [nvarchar](50) NOT NULL,
	[Description] [nvarchar](100) NULL,
 CONSTRAINT [PK_Region] PRIMARY KEY CLUSTERED 
(
	[RegionCode] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
INSERT [dbo].[Region] ([RegionCode], [RegionName],[Description]) VALUES ('Region Code 1', 'Region Name 1','Description for Region Code 1')
INSERT [dbo].[Region] ([RegionCode], [RegionName],[Description]) VALUES ('Region Code 2', 'Region Name 2','Description for Region Code 1')
INSERT [dbo].[Region] ([RegionCode], [RegionName],[Description]) VALUES ('Region Code 3', 'Region Name 3','Description for Region Code 3')
INSERT [dbo].[Region] ([RegionCode], [RegionName],[Description]) VALUES ('Region Code 4', 'Region Name 4','Description for Region Code 4')
INSERT [dbo].[Region] ([RegionCode], [RegionName],[Description]) VALUES ('Region Code 5', 'Region Name 5','Description for Region Code 5')
INSERT [dbo].[Region] ([RegionCode], [RegionName],[Description]) VALUES ('Region Code 6', 'Region Name 6','Description for Region Code 6')
INSERT [dbo].[Region] ([RegionCode], [RegionName],[Description]) VALUES ('Region Code 7', 'Region Name 7','Description for Region Code 7')
INSERT [dbo].[Region] ([RegionCode], [RegionName],[Description]) VALUES ('Region Code 8', 'Region Name 8','Description for Region Code 8')
INSERT [dbo].[Region] ([RegionCode], [RegionName],[Description]) VALUES ('Region Code 9', 'Region Name 9','Description for Region Code 9')
INSERT [dbo].[Region] ([RegionCode], [RegionName],[Description]) VALUES ('Region Code 10', 'Region Name 10','Description for Region Code 10')
INSERT [dbo].[Region] ([RegionCode], [RegionName],[Description]) VALUES ('Region Code 11', 'Region Name 11','Description for Region Code 11')
INSERT [dbo].[Region] ([RegionCode], [RegionName],[Description]) VALUES ('Region Code 15', 'Region Name 12','Description for Region Code 12')
INSERT [dbo].[Region] ([RegionCode], [RegionName],[Description]) VALUES ('Region Code 12', 'Region Name 13','Description for Region Code 13')
INSERT [dbo].[Region] ([RegionCode], [RegionName],[Description]) VALUES ('Region Code 13', 'Region Name 14','Description for Region Code 14')
INSERT [dbo].[Region] ([RegionCode], [RegionName],[Description]) VALUES ('Region Code 14', 'Region Name 15','Description for Region Code 15')

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO